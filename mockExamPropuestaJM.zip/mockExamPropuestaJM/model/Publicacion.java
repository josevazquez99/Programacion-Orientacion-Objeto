package mockExamPropuestaJM.model;

import java.time.LocalDateTime;
import java.util.Comparator;
import java.util.Objects;

import mockExamPropuestaJM.excepciones.PublicacionException;

public class Publicacion implements Valorable, Comparable<Publicacion>{
	
	protected String texto;
	private  LocalDateTime fechaCreacion;
	protected int valoracion;
	private int codigo;
	private static int codigoSiguiente;
	private Usuario usuario;
	private Valorable valorable;
	


	public Publicacion(String texto, Usuario usuario) {
		super();
		this.texto = texto;
		this.usuario = usuario;
		codigoSiguiente++;
		this.fechaCreacion=LocalDateTime.now();
	}
	

	public String getTexto() {
		return texto;
	}

	protected void setTexto(String texto) {
		this.texto = texto;
	}

	@Override
	public int hashCode() {
		return Objects.hash(valoracion);
	}

	@Override
	public boolean equals(Object obj) {
		boolean iguales=false;
		if (this == obj)
			iguales= true;
		if (obj == null)
			iguales= false;
		if (getClass() != obj.getClass())
			iguales= false;
		Publicacion other = (Publicacion) obj;
		iguales= valoracion == other.valoracion;
		return iguales;
	}


	public LocalDateTime getFechaCreacion() {
		return fechaCreacion;
	}

	public int getValoracion() {
		if(valorar("MUYBUENA")) {
			valoracion+=2;
		}else if(valorar("NORMAL")) {
			valoracion+=1;
		}else if(valorar("MUYMALA")){
			valoracion-=2;
		}
		return valoracion;
	}
	public boolean valorar(String valoracion) {
		boolean correcta=false;
		if(valoracion.equals("MUYBUENA") || valoracion.equals("BUENA") || valoracion.equals("NORMAL")) {
			correcta=true;
		}return correcta;
	}
	

	public int getCodigo() {
		return codigo;
	}



	public String getLoginUsuario() {
		return usuario.getLogin();
	}



	@Override
	public String toString() {
		return "Publicacion :<" + texto +  ", Realizada por:<" + usuario + "valoracion:<" + valoracion +"fechaCreacion:<" + fechaCreacion + ">"
				;
	}



	@Override
	public int compareTo(Publicacion o) {
		return this.valoracion-o.valoracion;
	}
	
	public boolean isAnterior(Publicacion o) {
		boolean fechaAnterior=false;
		if((this.fechaCreacion.compareTo(o.fechaCreacion)==1)){
			fechaAnterior=true;
		}
		return fechaAnterior;
	}




	
	
	
	
	
	
	
	
	
	
	

}
