package mockExamPropuestaJM.model;

import java.time.LocalDateTime;

import mockExamPropuestaJM.excepciones.PublicacionException;

public class Post extends Publicacion {
	private int numeroLecturas;
	private String tema;
	
	

	public Post(String texto, Usuario usuario, String tema) {
		super(texto, usuario);
		this.tema = tema;
	}
	protected void setTexto(String texto) {
		this.texto = texto;

	}
	public boolean Valorar(String valoracion) {
		return valorar(valoracion);
	}

	public int getNumeroLecturas() {
		return numeroLecturas;
	}

	public String getTema() {
		return tema;
	}


	@Override
	public String toString() {
		return "Post\n" + "Publicacion:\n" + getTexto() + "Realizada por:\n" + getLoginUsuario() + "Valoracion:\n"+
	getValoracion()+ "FechaPublicacion:\n" + getFechaCreacion();
	}
	
	
	

}
