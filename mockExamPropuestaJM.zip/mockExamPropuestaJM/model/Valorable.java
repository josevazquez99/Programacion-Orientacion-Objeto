package mockExamPropuestaJM.model;

public interface Valorable {
	
	public  boolean valorar(String valoracion);
	

}
