package mockExamPropuestaJM.model;

import java.util.Arrays;

import mockExamPropuestaJM.excepciones.MemoryStorageException;

public class MemoryStorage {

	private static final int NUM_MAXIMO_USUARIOS = 15;
	private static final int NUM_MAXIMO_PUBLICACIONES = 50;
	private int numUsuariosActuales;
	private int numPublicaciones;
	Usuario[] usuarios=new Usuario[NUM_MAXIMO_USUARIOS];
	Publicacion[] publicaciones=new Publicacion[NUM_MAXIMO_PUBLICACIONES];

	public MemoryStorage() {
		this.usuarios = new Usuario[NUM_MAXIMO_USUARIOS];
		this.publicaciones = new Publicacion[NUM_MAXIMO_PUBLICACIONES];

	}

	private int posicionUsuario(String login) {
		int posicion = 0;
		for (int i = 0; i < usuarios.length; i++) {
			if (usuarios[i]!=null && usuarios[i].getLogin().equals(login)) {
				posicion = i;

			}
		}
		return posicion;

	}

	public void addUsuario(String login, String pass) {
		if (numUsuariosActuales == NUM_MAXIMO_USUARIOS) {
			throw new MemoryStorageException("Error");
		}
		this.usuarios[this.numUsuariosActuales++] = new Usuario(login, pass);
	}

	public void addPublicacion(String texto, String login) {
		boolean encontrado=false;
		Usuario usuario=encontrarUsuario(login);
		if(usuario!=null) {
			encontrado=true;
		}else {
			throw new MemoryStorageException("Error");
		}
		if (numPublicaciones == NUM_MAXIMO_PUBLICACIONES) {
			publicaciones[0]=new Tweet(texto,usuario);
		}if(encontrado) {
		this.publicaciones[this.numPublicaciones++] = new Tweet(texto,usuario);}
	}

	public void addPublicacion(String texto, String login, String tema) {
		boolean encontrado=false;
		Usuario usuario=encontrarUsuario(login);
		if(usuario!=null) {
			encontrado=true;
		}else {
			throw new MemoryStorageException("Error");
		}
		if (numPublicaciones == NUM_MAXIMO_PUBLICACIONES) {
			publicaciones[0]=new Post(texto, usuario, tema);
		}
		if(encontrado) {
		this.publicaciones[this.numPublicaciones++] = new Post(texto, usuario, tema);}
	}

	public void addPublicacion(String texto, String login, int numeroEstrellas) {
		boolean encontrado=false;
		Usuario usuario=encontrarUsuario(login);
		if(usuario!=null) {
			encontrado=true;
		}else {
			throw new MemoryStorageException("Error");
		}
		if (numPublicaciones == NUM_MAXIMO_PUBLICACIONES) {
			publicaciones[0]=new Recomendacion(texto, usuario, numeroEstrellas);
		}
		if(encontrado) {
		this.publicaciones[this.numPublicaciones++] = new Recomendacion(texto, usuario, numeroEstrellas);}
	}
	public Usuario encontrarUsuario(String login) {
		Usuario usuario=null;
		for(int i=0;i<usuarios.length;i++) {
			if(usuarios[i].getLogin().equals(login)) {
				usuarios[i]=usuario;
			}
		}return usuario;
		
	}
	
	public String mostrarListaPublicaciones() {
		StringBuilder sb =new StringBuilder();
		for(int i=0;i<publicaciones.length;i++) {
			if(publicaciones[i]!=null) {
				sb.append(this.publicaciones[i]);
			}
		}
		return sb.toString();
	}
	
	public String mostrarTweets() {
		StringBuilder sb =new StringBuilder();
		for(int i=0;i<publicaciones.length;i++) {
			if(this.publicaciones[i] instanceof Tweet) {
				sb.append(this.publicaciones[i]);
			}
		}
		return sb.toString();
	}
	public String mostrarPost() {
		StringBuilder sb =new StringBuilder();
		for(int i=0;i<publicaciones.length;i++) {
			if(this.publicaciones[i] instanceof Post) {
				sb.append(this.publicaciones[i]);
			}
		}
		return sb.toString();
	}
	
	public String mostrarRecomendacion() {
		StringBuilder sb =new StringBuilder();
		for(int i=0;i<publicaciones.length;i++) {
			if(this.publicaciones[i] instanceof Recomendacion) {
				sb.append(this.publicaciones[i]);
			}
		}
		return sb.toString();
	}
	
	}
	
	
	
	

