package mockExamPropuestaJM.model;

import java.time.LocalDateTime;

import mockExamPropuestaJM.excepciones.PublicacionException;

public class Recomendacion extends Publicacion {
	private int numeroEstrellas;

	
	
	
	public Recomendacion(String texto, Usuario usuario,int numeroEstrellas) {
		super(texto, usuario);
		this.numeroEstrellas = numeroEstrellas;
	}

	protected void setTexto(String texto) {
		this.texto = texto;

	}

	public int getNumeroEstrellas() {
		return numeroEstrellas;
	}

	@Override
	public String toString() {
		return "Recomendacion\n" + "Publicacion:\n" + getTexto() + "Realizada por:\n" + getLoginUsuario() + "Valoracion:\n"+
	getValoracion()+ "FechaPublicacion:\n" + getFechaCreacion() + "Numero de estrellas:\n" + getNumeroEstrellas();
	}

	
	
	
	
	
	
	


}
