package mockExamPropuestaJM.model;

import java.util.Objects;

public class Usuario {
	
	private String login;
	private String pass;
	
	public Usuario(String login, String pass) {
		super();
		this.login = login;
		this.pass = pass;
	}

	public String getLogin() {
		return login;
	}

	public boolean setPass(String pass,String newpass) {
		boolean cambiada=false;
		if(checkPass(pass)) {
			this.pass=newpass;
			cambiada=true;
		}return cambiada;
	}
	public boolean checkPass(String pass) {
		boolean correcta=false;
		if(this.pass.equals(pass)) {
			correcta=true;
		}return correcta;
		
	}

	@Override
	public int hashCode() {
		return Objects.hash(login);
	}

	@Override
	public boolean equals(Object obj) {
		boolean iguales=this==obj;
		if (this == obj && obj != null && obj instanceof Usuario) {
		Usuario other = (Usuario) obj;
		iguales=Objects.equals(login, other.login);}
		return iguales;
	}
	
	
	
	

}
