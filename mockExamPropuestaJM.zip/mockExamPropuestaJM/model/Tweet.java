package mockExamPropuestaJM.model;

import java.time.LocalDateTime;

import mockExamPropuestaJM.excepciones.PublicacionException;

public class Tweet extends Publicacion {


	public Tweet(String texto, Usuario usuario) {
		super(texto, usuario);
		if(texto.length()>50) {
			throw new PublicacionException("Error");
		}
	}	


	protected void setTexto(String texto) {
		this.texto = texto;

	}
	
	
	public boolean Valorar(String valoracion) {
		return valorar(valoracion);
	}


	@Override
	public String toString() {
		return "Tweet\n" + "Publicacion:\n" + getTexto()+"\n" + "Realizada por:\n" + getLoginUsuario()+"\n" + "Valoracion:\n"+
	getValoracion()*2+"\n" +"FechaPublicacion:\n" + getFechaCreacion();
	}
	
	

}
