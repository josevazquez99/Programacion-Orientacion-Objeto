package mockExamPropuestaJM.model;

public enum Valoraciones {
	MUYBUENA,NORMAL,MUYMALA;

	
	Valoraciones() {}
}
