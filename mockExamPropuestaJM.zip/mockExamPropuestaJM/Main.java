package mockExamPropuestaJM;

import mockExamPropuestaJM.model.MemoryStorage;
import mockExamPropuestaJM.model.Publicacion;
import mockExamPropuestaJM.model.Tweet;
import mockExamPropuestaJM.model.Usuario;

public class Main {

	public static void main(String[] args) {
		
		MemoryStorage m = new MemoryStorage();
		Usuario u =new Usuario("jose99", "lopera99");
		System.out.println(u.getLogin());
		Publicacion p =new Publicacion("Bienvenido usuario", u);
		Tweet t= new Tweet("Bienvenido chuli", u);
		System.out.println(t.toString());


	}

}
